import java.io.*;

public class LanzaSumas
{
    static int numero1;
    static int numero2;
    static int suma;
    static FileWriter writer;

    public static void main(String[] args)
    {
        try
        {
            numero1 = Integer.parseInt(args[0]);
            numero2 = Integer.parseInt(args[1]);
            for (int i = numero1; i <= numero2; i++)
            {
                suma += i;
            }
            for (int i = 2; i <= 500; i++)
            {

                writer = new FileWriter(new File("Suma" + i + ".txt"));
                writer.write(String.valueOf(suma));
                writer.flush();
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}
