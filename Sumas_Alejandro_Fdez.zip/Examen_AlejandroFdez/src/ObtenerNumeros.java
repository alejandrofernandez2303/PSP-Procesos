import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ObtenerNumeros
{
    static int num1;
    static int num2;
    public static void main(String[] args) throws IOException
    {
        int n1 = Integer.parseInt(args[0]);
        int n2 = Integer.parseInt(args[1]);

        ProcessBuilder pb = new ProcessBuilder("java", "LanzaSumas", args[0], args[1]);
        pb.directory(new File(".\\out\\production\\Examen_AlejandroFdez"));
        Process p = pb.start();
        p.getInputStream();

        if(n1 > n2)
        {
            System.out.println(n1 + " mayor que " + n2);
        }
        else
        {
            System.out.println(n2 + " mayor que " + n1);
        }

        for (int i = 2; i <= 500; i++)
        {
            num1 = Integer.parseInt(args[0]);
            num1 += 5;
            num2 = Integer.parseInt(args[1]);
            num2 += 5;
            args[0] = String.valueOf(num1);
            args[1] = String.valueOf(num2);
        }
    }
}
