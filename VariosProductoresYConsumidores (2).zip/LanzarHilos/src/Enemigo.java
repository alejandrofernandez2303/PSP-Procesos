public class Enemigo implements NPC
{

    @Override
    public void mover()
    {

    }

    @Override
    public void hablar()
    {

    }

    @Override
    public void repetirComportamiento()
    {

    }
}
