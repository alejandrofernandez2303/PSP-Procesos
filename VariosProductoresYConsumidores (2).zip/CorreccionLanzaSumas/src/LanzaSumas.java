public class LanzaSumas
{

}
