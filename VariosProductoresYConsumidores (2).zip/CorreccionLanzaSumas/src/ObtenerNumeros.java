public class ObtenerNumeros
{
    public static void main(String[] args)
    {

    }
}
