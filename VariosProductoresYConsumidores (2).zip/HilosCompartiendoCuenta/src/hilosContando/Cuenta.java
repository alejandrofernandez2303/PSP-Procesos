package hilosContando;

public class Cuenta
{
    int cuenta = 0;

    public void incrementarCuenta()
    {
        cuenta++;
        System.out.println("La cuenta va por: " + cuenta);
    }
}
