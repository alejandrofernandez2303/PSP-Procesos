public class ObjetoCompartido
{
    int numAdivinar;

    public ObjetoCompartido(int numAdivinar)
    {
        this.numAdivinar = numAdivinar;
    }
}
