import java.io.File;

public class main
{
    public static void main(String[] args) {
        File fihce = new File("entrada.txt");
    }
}
